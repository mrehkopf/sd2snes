sd2snes-PCB_Edges.gbr is the PCB outline file.

